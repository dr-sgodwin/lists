/** Automatically generated file. DO NOT MODIFY */
package com.smg.mylist;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}